import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { bodyOf } from './helpers.mjs';

/** Same thousands separator the page uses, so expectations read like the bar. */
const n = (v) => Number(v).toLocaleString('en-GB');
import { localMultiplier } from '../shared/scoring.mjs';
import { displayBanked, applyCompletion } from '../shared/scoring.mjs';

/**
 * The stream overlay. GET /overlay/<name>
 *
 * This one is not a page, it is a browser source sitting on top of somebody
 * else's gameplay, and almost every test here is about that difference: no
 * branding on it, no background behind it, no error card across their screen,
 * and no query that reads a library to print one line.
 */
const mod = await import('../functions/overlay/[name].js');

const MEMBER = {
  psn_account_id: 'acct-1', psn_online_id: 'Pelzio', rank: 2, points: 148220,
  completion: 92.55, platinum: 143, gold: 1050, silver: 1203, bronze: 2201,
  projects: 159, completed: 144,
};

// Nine own it here, three have the platinum, so the multiplier is real.
const PLAYING = {
  np_comm_id: 'NPWR_INDY', title: 'Indiana Jones and the Great Circle',
  platform: 'PS5', icon_url: 'https://x.test/indy.png', trophy_count: 46,
  max_points: 3948, local_started: 9, unobtainable: 0,
  points: 1410, progress: 90, earned_total: 43, plat_local: 3,
};

let lastPlayingSql = '';
let lastPlayingBind = [];

const fakeEnv = ({ member = MEMBER, playing = PLAYING, total = 70, ahead = null, onStream = 0 } = {}) => ({
  DB: {
    prepare(sql) {
      return {
        bind: (...args) => ({
          first: async () => {
            if (sql.includes('FROM member_trophies')) return { c: onStream };
            // The rank lookup and the member lookup are both FROM members, so
            // the stub has to tell them apart by what they select.
            if (sql.includes('SELECT rank, points')) return ahead;
            if (sql.includes('FROM members')) return member;
            lastPlayingSql = sql;
            lastPlayingBind = args;
            return playing;
          },
        }),
        // Only the ranked-count query is bound to nothing.
        first: async () => ({ c: total }),
      };
    },
  },
});

const render = async (opts = {}, qs = '') => {
  const res = await mod.onRequestGet({
    env: fakeEnv(opts),
    request: new Request(`https://platinumintel.co.uk/overlay/Pelzio${qs}`),
    params: { name: 'Pelzio' },
  });
  return { res, out: await res.text() };
};

test('it carries no branding of any kind', async () => {
  /**
   * THE RULE THE WHOLE FEATURE HANGS ON. Martin: "i dont want it to be OH LET
   * ME BRAND YOUR CHANNEL". An overlay that advertises a Discord comes off the
   * layout in a week, and the thing that actually spreads it is chat asking
   * the streamer what the bar is.
   *
   * This checks the WHOLE document rather than the body, because a logo hidden
   * in a background-image in the stylesheet would be just as visible on screen
   * as one in the markup.
   */
  const { out } = await render();
  for (const brand of ['Platinum Intel', 'platinumintel', 'Kraken', 'discord.gg', 'kofi', 'Ko-fi']) {
    assert.ok(!out.toLowerCase().includes(brand.toLowerCase()), `"${brand}" is on the overlay`);
  }
  assert.ok(!out.includes('<img src="/Kraken'), 'no mark');
});

test('the background is transparent, so it does not black out the gameplay', async () => {
  const { out } = await render();
  assert.match(out, /html,body\{margin:0;background:transparent\}/, 'the body paints nothing');
  // The bar itself is allowed a surface. That is the point of it.
  assert.match(out, /\.bar\{[\s\S]*?background:linear-gradient/, 'but the bar has one');
});

test('it repaints itself without any JavaScript', async () => {
  const { out } = await render();
  assert.match(out, /<meta http-equiv="refresh" content="60">/, 'a meta refresh, not a script');
  assert.ok(!out.includes('<script'), 'no script tag anywhere');
  assert.ok(!/on(load|click|error)=/.test(out), 'and no inline handlers');
});

test('the three zones, in the order they were asked for', async () => {
  const body = bodyOf((await render()).out);
  const game = body.indexOf('Indiana Jones');
  const points = body.indexOf('class="pts"');
  const rank = body.indexOf('class="rank"');
  const cups = body.indexOf('class="cups"');

  assert.ok(game > 0 && points > game, 'the game comes before ours');
  assert.ok(cups > rank, 'and the cabinet comes last');

  /**
   * POINTS LEAD THE MIDDLE, NOT RANK. Martin: "i wouldnt start with rank i
   * would start with points since its next to the game". The points are about
   * the game, so they belong beside it; the rank is about the person.
   */
  assert.ok(points < rank, 'points before rank inside the middle');
});

test('the middle is the only part that can be switched off', async () => {
  const on = bodyOf((await render()).out);
  const off = bodyOf((await render({}, '?mid=0')).out);

  assert.match(on, /class="rank"/, 'rank shows by default');
  assert.ok(!off.includes('class="rank"'), 'and goes with the middle');
  assert.ok(!off.includes('class="pts"'), 'so do the points');

  // The two ends must survive, and the gap they leave must be a spacer rather
  // than a jump.
  assert.match(off, /Indiana Jones/, 'the game stays');
  assert.match(off, /class="cups"/, 'so does the cabinet');
  assert.match(off, /class="spacer"/, 'and the middle leaves a hole, not a shuffle');
});

test('the hours slot is gone, and so is the clock that drew it', async () => {
  /**
   * IT WAS RESERVED SPACE and it is not any more. Martin asked for the slot so
   * the streaming board would have somewhere to land: "just have a space ready
   * for it". It then sat at half opacity reading 00.0h on every bar for weeks,
   * which is a feature announcing that it does not work.
   *
   * He went off the metric as well, which is the better reason: "i dont think
   * it makes much sense, wow this guy streams more than me ? so what". Hours
   * measure endurance, not hunting. When the streaming board lands it wants
   * what happened in those hours rather than the hours, and none of that fits
   * a slot shaped like a clock.
   */
  const body = bodyOf((await render()).out);
  assert.ok(!body.includes('00.0h'), 'no placeholder');
  assert.ok(!body.includes('class="seg hold"'), 'and no empty segment holding its place');

  const src = readFileSync(fileURLToPath(new URL('../functions/overlay/[name].js', import.meta.url)), 'utf8');
  assert.ok(!/const CLOCK =/.test(src), 'the icon it used went with it');
});

test('the multiplier only appears when it is doing something', async () => {
  // Three of nine finished, so it is genuinely paying more here.
  const busy = bodyOf((await render()).out);
  const mult = localMultiplier(3, 9);
  assert.ok(mult > 1.005, 'the fixture is a live multiplier');
  assert.match(busy, new RegExp(`&times;${mult.toFixed(2)}`), 'and it is printed');
  /**
   * THE NUMBER ALONE. It printed "x1.13 7 stuck" and Martin cut the tail:
   * seven words of explanation on a bar with no room to spare, for something
   * chat asks about anyway. The number is the hook, the streamer is the answer.
   */
  assert.ok(!/stuck/.test(busy), 'and nothing explaining it');

  // Everybody who owns it has finished it, so the chip is noise.
  const settled = bodyOf(
    (await render({ playing: { ...PLAYING, plat_local: 9 } })).out,
  );
  assert.ok(!settled.includes('class="mult"'), 'a flat 1.00 chip takes space to say nothing');

  // Two owners is below the contested floor, so there is no local evidence yet.
  const lonely = bodyOf(
    (await render({ playing: { ...PLAYING, local_started: 2, plat_local: 0 } })).out,
  );
  assert.ok(!lonely.includes('class="mult"'), 'no multiplier off two owners');
});

test('points are banked through the completion, like every other surface', async () => {
  /**
   * The same trap the hunter page fell into: `mg.points` is the price list for
   * the game, identical for everybody holding those trophies, and printing it
   * raw tells two members with very different completions that they are
   * getting the same number.
   */
  const body = bodyOf((await render()).out);
  const got = displayBanked(PLAYING.points, MEMBER.completion);
  const max = displayBanked(PLAYING.max_points, MEMBER.completion);
  assert.ok(got < PLAYING.points, 'the fixture actually exercises the multiplier');
  assert.match(body, new RegExp(got.toLocaleString('en-GB')), 'banked, not raw');
  assert.match(body, new RegExp(max.toLocaleString('en-GB')), 'out of the banked full');
});

test('the cabinet is started against completed, with the account percent', async () => {
  const body = bodyOf((await render()).out);
  assert.match(body, /144\/159/, 'completed out of started');
  assert.match(body, /92\.55%/, 'and their completion');
  assert.match(body, /143/, 'platinums');
  assert.match(body, /2,201/, 'and bronzes, formatted');
});

test('a name nobody has shows nothing at all, and is not cached', async () => {
  /**
   * A visible "no such hunter" card would sit across somebody's gameplay for a
   * whole stream, and they would have no idea where it came from. Empty is the
   * only safe failure for something living in another person's layout.
   */
  const { res, out } = await render({ member: null });
  assert.equal(res.status, 404);
  // Two stylesheets now: the sheet, then the one line carrying the size dial.
  const empty = out.slice(out.lastIndexOf('</style>'))
    .replace(/<\/style>|<\/head>|<body>|<\/body>|<\/html>|\s/g, '');
  assert.equal(empty, '', 'nothing between body and the end of the document');
  assert.match(res.headers.get('cache-control'), /no-store/, 'a typo must not stick');
});

test('one row for the game, and it leans on the index that makes that possible', async () => {
  /**
   * THIS IS THE COST TEST. It runs every sixty seconds for as long as somebody
   * streams. MRTheChez owns 1,512 games, so a query that sorted a library to
   * find one row would read close to a million rows over one evening, against
   * a free tier of five million a day for the entire board.
   */
  await render();
  assert.match(lastPlayingSql, /LIMIT 1/, 'one row');
  assert.match(lastPlayingSql, /ORDER BY COALESCE\(mg\.last_played_at/, 'newest first');
  assert.deepEqual(lastPlayingBind, ['acct-1'], 'scoped to one member');
  assert.ok(!/COUNT\(\*\)[\s\S]*FROM member_games/.test(lastPlayingSql), 'nothing counted');

  const migration = await readFile(
    new URL('../migrations/017-overlay-recent.sql', import.meta.url), 'utf8',
  );
  assert.match(
    migration,
    /ON member_games\(psn_account_id, last_played_at DESC\)/,
    'and the index that ORDER BY needs actually exists',
  );
});

test('it caches for less time than it refreshes', async () => {
  // A five minute cache on a bar that repaints every sixty seconds would mean
  // four out of five repaints showed the same numbers back.
  const { res } = await render();
  const max = Number(/max-age=(\d+)/.exec(res.headers.get('cache-control'))?.[1]);
  assert.ok(max > 0 && max <= 30, `cache ${max}s should sit under the refresh`);
});

test('position is a whitelist, not a string from the query', async () => {
  const bottom = bodyOf((await render()).out);
  assert.match(bottom, /class="bar bottom"/, 'bottom by default');

  const top = bodyOf((await render({}, '?pos=top')).out);
  assert.match(top, /class="bar top"/);

  const junk = bodyOf((await render({}, '?pos=" onload="alert(1)')).out);
  assert.match(junk, /class="bar bottom"/, 'anything else falls back');
  assert.ok(!junk.includes('onload'), 'and never reaches the markup');
});

test('a member the scan has not reached yet still renders', async () => {
  /**
   * Somebody registers, adds the overlay before their first scan finishes, and
   * goes live. Their cabinet is known from their member row; the game is not.
   * The bar has to survive that rather than throw a 500 into OBS.
   */
  const { res, out } = await render({ playing: null });
  const body = bodyOf(out);
  assert.equal(res.status, 200);
  assert.match(body, /Nothing scanned yet/);
  assert.match(body, /class="cups"/, 'the cabinet still shows');
  assert.ok(!body.includes('class="pts"'), 'and the middle has nothing to say');
});

test('a flagged game says so on the bar', async () => {
  const body = bodyOf((await render({ playing: { ...PLAYING, unobtainable: 1 } })).out);
  assert.match(body, /class="warn"/, 'the mark is there');
});

test('the ordinal is right, including the teens', async () => {
  for (const [rank, mark] of [[1, 'st'], [2, 'nd'], [3, 'rd'], [4, 'th'],
    [11, 'th'], [12, 'th'], [13, 'th'], [21, 'st'], [22, 'nd'], [23, 'rd']]) {
    const body = bodyOf((await render({ member: { ...MEMBER, rank } })).out);
    assert.match(body, new RegExp(`>${rank}<sup>${mark}</sup>`), `${rank}${mark}`);
  }
});

test('the size dial is a dial, and it is clamped', async () => {
  /**
   * "text is very small" came back from more than one person, and no single
   * number fixes it: people stream at 1080 and at 1440 with layouts of every
   * size. The bar is sized in em off one root value, so this is one parameter
   * rather than a redesign. Clamped, because a URL handed to a streamer must
   * not be able to draw a bar taller than their game.
   */
  assert.match((await render()).out, /--s:1\}/, 'normal by default');
  assert.match((await render({}, '?scale=125')).out, /--s:1\.25\}/);
  assert.match((await render({}, '?scale=900')).out, /--s:2\}/, 'clamped at the top');
  assert.match((await render({}, '?scale=10')).out, /--s:0\.7\}/, 'and at the bottom');
  assert.match((await render({}, '?scale=nonsense')).out, /--s:1\}/, 'junk falls back');
});

test('nothing on the bar is grey', async () => {
  /**
   * Martin: "the gray text is almost impossible to see with backgrounds so keep
   * it white". The site's palette does not transfer here, because a page has a
   * dark surface behind it and this has whatever the game is doing. Hierarchy
   * is carried by weight and size, and every scrap of text sits on its own
   * shadow so it never depends on the panel behind it.
   */
  const { out } = await render();
  const vars = out.slice(out.indexOf(':root{'), out.indexOf('}', out.indexOf(':root{')));
  assert.match(vars, /--ink:#ffffff/);
  assert.match(vars, /--soft:#eaf2f0/, 'the second tier is still nearly white');
  assert.match(out, /text-shadow:0 1px 2px rgba\(0,0,0,\.9\)/, 'and it carries its own edge');
});

test('the four metals show for the game on screen', async () => {
  // The board has always shown a person's cabinet; nothing showed the same
  // breakdown for the thing they are actually playing.
  const body = bodyOf((await render({
    playing: {
      ...PLAYING, earned_platinum: 0, earned_gold: 3, earned_silver: 8, earned_bronze: 32,
    },
  })).out);

  // Scoped to the GAME's cups. The account cabinet on the right always carries
  // a platinum count, so checking the whole document for "c-plat" would be
  // asserting against the wrong half of the bar.
  const i = body.indexOf('class="cups gcups"');
  assert.ok(i > 0, 'the game cups are drawn');
  const gcups = body.slice(i, body.indexOf('</span>', body.indexOf('</span>', i) + 1));

  assert.match(gcups, /class="c-gold">.*?3/s);
  assert.ok(/class="c-bron"/.test(body.slice(i)), 'and the bronzes');
  // A game with no platinum earned must not print a blank platinum: half the
  // width of the bar would go on noughts.
  assert.ok(!/class="c-plat"/.test(gcups), 'zeroes are left out');
});

test('the rank and the chase are one segment, and the chase wins the space', async () => {
  /**
   * Martin: "add rank 31st xxxx points to 30?". They were two segments, which
   * spent a divider and two lots of padding saying one thing in two halves,
   * and meant the useful half went first when the bar ran out of room.
   *
   * "OF 71" IS THE FALLBACK, NOT THE DEFAULT. It says how big the field is;
   * the chase says what to do about it, in the same space. Somebody in first
   * has nobody to chase, so they get the field size rather than "0 to 0th".
   */
  const body = bodyOf((await render({ ahead: { rank: 1, points: 152000 } })).out);
  assert.match(body, /class="gap s-gap"/, 'the chase is inside the rank segment');
  assert.match(body, /3,780<\/b> to 1st/, 'the difference of two stored numbers');
  assert.ok(!body.includes('of 71'), 'and it has taken the field size\'s place');

  const first = bodyOf((await render({ member: { ...MEMBER, rank: 1 } })).out);
  assert.ok(!first.includes('class="gap'), 'nobody to chase');
  assert.match(first, /class="of"/, 'so the field size comes back rather than nothing');
});

test('the game points sit on the left but belong to the middle', async () => {
  /**
   * Martin: "could we have the game points ... on the left hand side next to
   * the time, still count it as the middle section so if people hide our side
   * of things it hides". So position and ownership are different things here,
   * and the switch has to respect ownership.
   */
  const on = bodyOf((await render()).out);
  const left = on.indexOf('class="pts"');
  const mid = on.indexOf('class="zone mid"');
  assert.ok(left > 0 && left < mid, 'printed before the middle zone starts');

  const off = bodyOf((await render({}, '?mid=0')).out);
  assert.ok(!off.includes('class="pts"'), 'and it goes when the middle goes');
});

test('the games icon is a controller, not three rectangles', async () => {
  const { out } = await render();
  assert.match(out, /class="ic pad"/);
  assert.ok(!out.includes('<rect x="3" y="4"'), 'the old stacked bars are gone');
});

test('the bar climbs through the bands, and matches the website exactly', async () => {
  /**
   * SAME RULE AS THE WEBSITE, from the same function. These two had already
   * drifted once: a finished game went green on the site and stayed platinum
   * blue here, and Leon has both open at the same time. The colours below are
   * the overlay's own palette, but the DECISION comes from barShade, so the
   * only way for these to disagree again is for somebody to stop calling it.
   *
   * Bronze to 39, silver 40 to 69, gold 70 to 99, green at 100, platinum
   * overriding at any percentage because no percentage can say it.
   */
  const at = (progress, cups = {}) => render({ playing: { ...PLAYING, progress, ...cups } });
  const fillOf = (out) => /class="fill"[^>]*background:([^"]+)"/.exec(bodyOf(out))?.[1];

  const cups = { earned_platinum: 0, earned_gold: 4, earned_silver: 6, earned_bronze: 20 };

  assert.equal(fillOf((await at(4, cups)).out), 'var(--bronze)', '4% is bronze despite the golds');
  assert.equal(fillOf((await at(39, cups)).out), 'var(--bronze)', '39 is the top of bronze');
  assert.equal(fillOf((await at(40, cups)).out), 'var(--silver)', '40 is the floor of silver');
  assert.equal(fillOf((await at(69, cups)).out), 'var(--silver)', '69 is the top of silver');
  assert.equal(fillOf((await at(70, cups)).out), 'var(--gold)', '70 is the floor of gold');
  assert.equal(fillOf((await at(99, cups)).out), 'var(--gold)', '99 is the top of gold');

  /**
   * THE GAP THIS CLOSED. There was no green case on this bar at all, so a
   * finished game sat here in platinum blue while the hunter page two tabs
   * across showed it green.
   */
  assert.equal(fillOf((await at(100, cups)).out), 'var(--accent)', '100 is green, as on the site');

  assert.equal(
    fillOf((await at(84, { ...cups, earned_platinum: 1 })).out),
    'var(--plat)',
    'the platinum outranks the band',
  );
  assert.equal(
    fillOf((await at(0, { earned_platinum: 0, earned_gold: 0, earned_silver: 0, earned_bronze: 0,
      earned_total: 0 })).out),
    'var(--accent)',
    'and a game with nothing earned yet is not painted bronze',
  );
});

test('every game bar on the project asks the same function', async () => {
  /**
   * THE ACTUAL FIX, and the reason this test is here rather than a comment.
   *
   * Three files drew a game progress bar and all three worked out the colour
   * themselves. They drifted, quietly, and the way anybody found out was Leon
   * having the overlay and his own hunter page open at once and seeing one game
   * in two colours. A comment saying "keep these in sync" is a comment. This
   * fails the build.
   */
  const { readFile } = await import('node:fs/promises');
  const files = [
    'functions/hunter/[name].js',
    'functions/game/[id].js',
    'functions/overlay/[name].js',
  ];

  for (const f of files) {
    const src = await readFile(f, 'utf8');
    assert.match(src, /barShade/, `${f} does not use the shared shade`);
    // The old ladder, in any of its spellings. If this comes back, so does the
    // drift.
    assert.ok(
      !/earned_gold\)\s*>\s*0\s*$/m.test(src) && !/\?\s*'g'\s*$/m.test(src),
      `${f} is working the colour out for itself again`,
    );
  }
});

test("Leon's link with two question marks still works", async () => {
  /**
   * THE REAL ONE, from a real morning. `?pos=top?scale=150` loses BOTH
   * settings and says nothing: `pos` arrives as the string "top?scale=150",
   * which is not "top", so the bar drops to the bottom edge; and `scale`
   * arrives as null, so the size is ignored. It looked exactly like OBS
   * refusing to resize, and that is where the twenty minutes went.
   *
   * A 44 pixel tall source hid half of it, because at that height the top edge
   * and the bottom edge are the same place.
   */
  const bad = await render({}, '?pos=top?scale=150');
  const good = await render({}, '?pos=top&scale=150');

  assert.match(bad.out, /--s:1\.5/, 'the scale is read');
  assert.match(bad.out, /class="bar top"/, 'and so is the position');
  assert.equal(bodyOf(bad.out), bodyOf(good.out), 'it renders as the link he meant');
});

test('a normal link is not touched by the mending', async () => {
  const plain = await render();
  assert.match(plain.out, /--s:1}/, 'no scale means no scale, not 70 per cent');
  assert.match(plain.out, /class="bar bottom"/, 'and the default edge');
});

test('segments hold their size instead of sliding over each other', async () => {
  /**
   * THE BUG MARTIN SAW: "the middle is fucked". At scale 150 the bar wanted
   * 2,640 pixels of content in a 1,920 pixel canvas, and because every segment
   * is white-space:nowrap AND allowed to shrink, they did not wrap and did not
   * clip. They kept their text at full width and slid it over the neighbour, so
   * "00.0h" printed on top of the boost chip and the chase printed on top of
   * the cabinet.
   *
   * flex:none is the whole fix. Everything else below is about what to shed
   * once the segments refuse to squash.
   */
  const { out } = await render();
  assert.match(out, /\.seg\{flex:none\}/, 'segments cannot be squashed');
  assert.match(out, /\.bar\{overflow:hidden\}/, 'and clipping is the last resort');
});

test('the bar sheds what it cannot fit, in order, and says so in the CSS', async () => {
  const { out } = await render({}, '?scale=150');
  const css = out.slice(out.indexOf('--s:'));

  const at = (rule) => css.indexOf(rule);
  assert.ok(at('padding:0 .55em') > -1, 'padding tightens first');
  assert.ok(at('.seg.s-mult') > at('padding:0 .55em'), 'then the boost, which is ours but not read');
  assert.ok(at('.seg.s-gcups') > at('.seg.s-mult'), 'then the game cups');
  assert.ok(at('.s-gap') > at('.seg.s-gcups'), 'then the chase');

  /**
   * THE CABINET IS LAST, and this assertion is the point of the test.
   *
   * Value per pixel put it third, because it is the biggest thing on the bar
   * and the same figures are on the profile page. It went, Martin saw his own
   * overlay without it, and: "the trophies need to be on the right where they
   * were!" It is the thing a viewer actually looks at, so it outranks every
   * other droppable on the bar regardless of what it costs in pixels.
   */
  assert.ok(at('.seg.s-cab') > at('.seg.s-gap'), 'the cabinet outlasts the chase');
  assert.ok(at('.seg.s-cab') > at('.seg.s-comp'), 'and the completion figure');
  assert.ok(at('.seg.s-cab') > at('.seg.s-mult'), 'and the boost, which now goes early');

  // The game, the progress and the rank are never in the ladder at all.
  assert.ok(!css.includes('.game{display:none'), 'the game is never dropped');
  assert.ok(!css.includes('.rank{display:none'), 'nor the rank');
});

test('the breakpoints are in real pixels, because a media query cannot see the scale', async () => {
  /**
   * `em` inside a media query is the browser's INITIAL font size, not the
   * page's, so the whole em-based sizing of this bar is invisible to one. The
   * server knows the scale and does the arithmetic instead, which also means it
   * works in whatever Chromium somebody's OBS shipped with rather than only in
   * the ones new enough for container queries.
   */
  const first = (out) => Number(/@media \(max-width:(\d+)px\)/.exec(out)?.[1]);

  const one = first((await render({}, '?scale=100')).out);
  const two = first((await render({}, '?scale=200')).out);

  assert.ok(one > 0 && two > 0, 'both emit breakpoints');
  assert.ok(two > one * 1.9 && two < one * 2.1, 'twice the scale is twice the breakpoint');
});

test('a short game title keeps more of the bar than a long one', async () => {
  /**
   * "2XKO" and "Indiana Jones and the Great Circle" are two hundred pixels
   * apart. A ladder built for the worst case would strip the cabinet off the
   * 2XKO bar to make room for characters it does not have, so the estimate uses
   * the title the page is actually about to draw.
   */
  const first = (out) => Number(/@media \(max-width:(\d+)px\)/.exec(out)?.[1]);

  const short = first((await render({ playing: { ...PLAYING, title: '2XKO' } })).out);
  const long = first(
    (await render({ playing: { ...PLAYING, title: 'Indiana Jones and the Great Circle' } })).out,
  );

  assert.ok(long > short, 'the long title reaches its first breakpoint sooner');
});

test('the controller ring is the green one', async () => {
  // Martin picked the console card icon for the ring, and the ring is the part
  // that makes it read at a glance.
  assert.match((await render()).out, /<circle[^>]*stroke="var\(--accent\)"/);
});


test('a fresh live note beats the scan, but only for the counts', async () => {
  /**
   * Leon popped a trophy, the card appeared, and the bar still said 10 of 18.
   * The poll was writing the trophy log and nothing else, so the counts stayed
   * on whatever his last update knew.
   *
   * The live note fixes the COUNTS and deliberately does not touch the POINTS.
   * Points are the rescore's to decide; an overlay guessing at them would be
   * the one place on this project where a number is invented rather than
   * printed.
   */
  const live = JSON.stringify({
    id: 'NPWR_INDY', at: Date.now() - 4000,
    progress: 61, platinum: 0, gold: 2, silver: 3, bronze: 6,
  });
  const body = bodyOf((await render({ member: { ...MEMBER, live_play: live } })).out);

  assert.match(body, />11\/46</, 'the counts are the poll\'s, seconds old');
  assert.match(body, /61\.00%/, 'and so is the progress');
  assert.match(body, /width:61\.00%/);

  // The price list is untouched: still the scan's banked figure.
  const got = displayBanked(PLAYING.points, MEMBER.completion);
  assert.match(body, new RegExp(got.toLocaleString('en-GB')), 'points stay the scan\'s');
});

test('a stale live note is ignored and the scan takes over again', async () => {
  /**
   * The poll only writes while somebody is streaming with the overlay up, so
   * the note stops the moment they stop. Fifteen minutes later the bar goes
   * back to what the scan knows rather than insisting forever that they are
   * still on last night's game.
   */
  const stale = JSON.stringify({
    id: 'NPWR_INDY', at: Date.now() - 40 * 60000,
    progress: 61, platinum: 0, gold: 2, silver: 3, bronze: 6,
  });
  const body = bodyOf((await render({ member: { ...MEMBER, live_play: stale } })).out);
  assert.match(body, />43\/46</, 'back to the stored counts');
  assert.match(body, /90\.00%/);
});

test('a live note that is not valid JSON is simply no note', async () => {
  // There is no version of a broken blob that is worth an exception on
  // somebody's stream.
  const { res, out } = await render({ member: { ...MEMBER, live_play: '{not json' } });
  assert.equal(res.status, 200);
  assert.match(bodyOf(out), />43\/46</);
});

test('the live note never writes to the scan\'s own numbers', async () => {
  /**
   * THE TRAP THIS AVOIDS. Writing fresh counts into `member_games` was the
   * obvious fix and it would have been quietly catastrophic: the scan decides
   * whether to re-fetch a game by comparing its stored count against PSN's, so
   * an updated count there would make it skip the game and never award the
   * points. Right for an evening, wrong forever.
   */
  const live = readFileSync(
    fileURLToPath(new URL('../worker/src/live.mjs', import.meta.url)), 'utf8',
  );
  assert.match(live, /UPDATE members SET live_play/, 'the note goes on the member row');
  assert.ok(!/UPDATE member_games/.test(live), 'and nothing here touches the scan\'s record');
  assert.ok(!/INSERT INTO member_games/.test(live));
});


test('the bar shows how much of it happened tonight', async () => {
  /**
   * Martin: "if someone has earned a trophy on stream show the bar gold/and
   * purple that way we can see what % we have earned on stream".
   *
   * Purple is the one colour on this bar that belongs to Twitch rather than to
   * PlayStation, which is exactly the point: it is the part of the game that
   * an audience watched happen.
   */
  const live = { ...MEMBER, live_since: Date.now() - 3600000, live_checked_at: Date.now() - 20000 };
  const body = bodyOf((await render({ member: live, onStream: 6 })).out);

  assert.match(body, /class="live" style="width:13\.95%"/, 'six of the forty three earned');
  assert.match(body, /\+6 live/, 'and it says how many in words too');

  // The total width is still the percentage printed beside it. Only the split
  // inside it is by count.
  assert.match(body, /width:90\.00%/);
  assert.match(body, /90\.00%<\/span>/);
});

test('no purple when nothing landed tonight, and none when they are off air', async () => {
  const live = { ...MEMBER, live_since: Date.now() - 3600000, live_checked_at: Date.now() - 20000 };
  const quiet = bodyOf((await render({ member: live, onStream: 0 })).out);
  assert.ok(!quiet.includes('class="live"'), 'a stream with no trophies yet is just the bar');
  assert.ok(!quiet.includes('live</span>'), 'and no count either');

  // Off air there is no "tonight" to count at all.
  const off = bodyOf((await render({ onStream: 9 })).out);
  assert.ok(!off.includes('class="live"'));
});

test('the boost pill says what it is', async () => {
  // "x1.13 7 stuck" was an explanation nobody had room for. Bare "x1.13" meant
  // nothing to a stranger. One word does both jobs.
  const body = bodyOf((await render()).out);
  assert.match(body, /class="mult">&times;[\d.]+ <small>boost<\/small>/);
});

test('the bar rings the poll, not just the trophy pop', async () => {
  /**
   * THE BUG. The doorbell lived only in the pop, so a streamer who added the
   * bar and not the pop was never polled: their bar showed whatever their last
   * /update saw and sat there for the whole broadcast.
   *
   * Martin, watching somebody else's stream: "this guy is playing on ps3 and
   * just synced, overlay hasnt updated and its showing an old ps5 game". He had
   * synced, so PSN knew. Nothing had asked PSN.
   *
   * It is also the quiet half of OBS's "shutdown source when not visible": a
   * pop in an off-air scene stops refreshing and used to take the bar's live
   * data down with it.
   */
  const rung = [];
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url) => { rung.push(String(url)); return new Response('ok'); };

  try {
    await mod.onRequestGet({
      env: fakeEnv(),
      request: new Request('https://platinumintel.co.uk/overlay/Pelzio'),
      params: { name: 'Pelzio' },
      waitUntil: (p) => p,
    });
  } finally {
    globalThis.fetch = realFetch;
  }

  assert.equal(rung.length, 1, 'exactly one knock');
  assert.match(rung[0], /\/poll\/Pelzio$/, 'and it names the hunter whose bar this is');
});

test('a bar with no waitUntil still renders', async () => {
  // Whatever the runtime hands us, an overlay must never fail to draw because
  // a background nicety was unavailable.
  const { res, out } = await render();
  assert.equal(res.status, 200);
  assert.ok(out.includes('class="bar'), 'the bar is there without a doorbell');
});

// ------------------------------------------------------- the live chase ----

/**
 * The gold figure moves while they play, which it did not.
 *
 * Martin: "leons points to earn to the next rank never moved untill he
 * /update". Same complaint he made about the game's points days earlier - a
 * segment where half the numbers are live and half are frozen, with nothing
 * saying which, is worse than one that is honestly stale all over. The game
 * points were fixed then and the rank segment was left behind.
 */
const RAW = { ...MEMBER, raw_points: 160150 };

/** A live note for the game being played, priced by the poll. */
const playNote = (points) =>
  JSON.stringify({
    id: PLAYING.np_comm_id, at: Date.now(), counts: true,
    progress: 90, platinum: 0, gold: 8, silver: 12, bronze: 23, points,
  });

test('earning points in the game closes the gap without an update', async () => {
  /**
   * The arithmetic is the board's own: swap the game's stale share of the raw
   * total for its live one, then run the WHOLE thing through applyCompletion
   * exactly as the rescore does. Flooring once, where the rescore floors once,
   * is what makes the bar agree with the update that follows it.
   */
  const live = 1410 + 300; // the poll priced 300 more than the scan stored
  const expected = applyCompletion(160150 - 1410 + live, MEMBER.completion);
  const body = bodyOf(
    (await render({
      member: { ...RAW, live_play: playNote(live) },
      ahead: { rank: 1, points: 152000 },
    })).out,
  );

  assert.match(body, new RegExp(`${n(152000 - expected)}</b> to 1st`), 'the live gap');
  assert.ok(!body.includes('3,780</b> to 1st'), 'and not the stored one');
});

test('with no live note the chase is exactly what it always was', async () => {
  // The fallback has to be the old behaviour, not an approximation of it.
  const body = bodyOf((await render({ member: RAW, ahead: { rank: 1, points: 152000 } })).out);
  assert.match(body, /3,780<\/b> to 1st/);
});

test('a member with no raw_points falls back rather than reading NaN', async () => {
  // Mid-first-scan, or a row an older build left behind. Every part of the sum
  // has to be present or the stored total stands.
  const body = bodyOf(
    (await render({
      member: { ...MEMBER, live_play: playNote(9999) },
      ahead: { rank: 1, points: 152000 },
    })).out,
  );
  assert.match(body, /3,780<\/b> to 1st/, 'the stored figure, not a broken one');
});

test('overtaking on points says so, and does not award the rank', async () => {
  /**
   * Ranks are the rescore's to give and nothing else's, so a bar that promoted
   * somebody before the board had would be the one number on this project that
   * is a claim rather than a reading. What it can say honestly is that the gap
   * is gone - which is the most interesting thing that happens on this bar all
   * night.
   */
  const body = bodyOf(
    (await render({
      member: { ...RAW, live_play: playNote(1410 + 40000) },
      ahead: { rank: 1, points: 152000 },
    })).out,
  );

  assert.match(body, /class="gap s-gap past"/, 'the segment changes state');
  assert.match(body, /<b>past<\/b> 1st/, 'and says what happened');
  assert.match(body, /class="rank">2<sup>/, 'while the rank itself stays put');
});
