import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

/**
 * Static checks on the Worker.
 *
 * These exist because of a real incident: a refactor replaced a range of text
 * that ran further than intended and deleted five commands and every button
 * handler — /rank, /leaderboard, /game, /backlog, View profile and
 * handleComponent — all at once. `node --check` passed, because the file was
 * still valid JavaScript. The unit tests passed, because they only covered
 * shared/. It shipped, and the first sign of trouble would have been a member
 * pressing a button.
 *
 * The Worker can't be imported here — it wants a Cloudflare env binding and a
 * D1 database — so these read the source instead. Crude, but they catch the
 * one failure mode that actually happened: a switch dispatching to something
 * that no longer exists.
 */
const SRC = readFileSync(
  fileURLToPath(new URL('../worker/src/index.mjs', import.meta.url)),
  'utf8',
);

const declared = () => {
  const names = new Set();
  for (const m of SRC.matchAll(/(?:async\s+)?function\s+(\w+)/g)) names.add(m[1]);
  for (const m of SRC.matchAll(/const\s+(\w+)\s*=/g)) names.add(m[1]);
  for (const m of SRC.matchAll(/import\s*\{([^}]+)\}/gs)) {
    for (const part of m[1].split(',')) names.add(part.trim().split(/\s+as\s+/).pop());
  }
  return names;
};

test('every slash command dispatches to a function that exists', () => {
  const names = declared();
  const block = SRC.slice(SRC.indexOf('async function handleCommand'));
  const cases = [...block.matchAll(/case '([\w-]+)':\s*return (\w+)\(/g)];

  assert.ok(cases.length >= 8, `expected the full command list, found ${cases.length}`);
  for (const [, command, fn] of cases) {
    assert.ok(names.has(fn), `/${command} calls ${fn}(), which is not defined anywhere`);
  }
});

test('every button dispatches to a function that exists', () => {
  const names = declared();
  const start = SRC.indexOf('async function handleComponent');
  assert.ok(start > 0, 'handleComponent is missing — every button in the bot is dead');

  const block = SRC.slice(start, start + 4000);
  for (const [, fn] of block.matchAll(/return (?:\{ \.\.\.update\(\(await )?(\w+)\(/g)) {
    if (['update', 'reply', 'errorReply'].includes(fn)) continue;
    assert.ok(names.has(fn), `a button calls ${fn}(), which is not defined anywhere`);
  }
});

test('the commands members actually use are all still present', () => {
  // Named explicitly, so deleting one is a failing test rather than a silent
  // regression. Every one of these was lost in the incident above.
  for (const fn of [
    'rank', 'leaderboard', 'game', 'backlog', 'profile', 'changelog',
    'register', 'verify', 'unlink', 'runUpdate', 'addMember',
    'handleComponent', 'handleAutocomplete', 'dispatchScan',
  ]) {
    assert.match(
      SRC,
      new RegExp(`(?:async\\s+)?function\\s+${fn}\\b`),
      `${fn}() has gone missing from the Worker`,
    );
  }
});

// -------------------------------------------------------- autocomplete ----

/**
 * The dropdown on /flag and /game, which Discord fires PER KEYSTROKE.
 *
 * Real behavioural tests rather than source greps, because what was wrong here
 * was not a missing function — it was a query reading the whole games table,
 * twenty-six thousand rows at a time, to build a list that then had the wrong
 * games in it.
 */
const dbmod = await import('../worker/src/db.mjs');

let lastSql = '';
let lastArgs = [];
const spyEnv = (rows = []) => ({
  DB: {
    prepare(sql) {
      lastSql = sql;
      return {
        bind: (...args) => {
          lastArgs = args;
          // `.first` as well as `.all`, because the resolvers behind the /flag
          // dropdowns read one row at a time.
          return {
            all: async () => ({ results: rows }),
            first: async () => rows[0] ?? null,
          };
        },
      };
    },
  },
});

test('the game search only reads games somebody here owns', async () => {
  // 26,042 rows per keystroke was a tenth of the bot's daily budget spent on a
  // dropdown. This cuts it to about 514 — and to exactly the right 514, since a
  // game nobody here owns cannot usefully be flagged or asked about.
  await dbmod.searchGames(spyEnv(), 'minecraft', 25);
  assert.match(lastSql, /local_started > 0/, 'unowned games are not searched');
  assert.match(lastSql, /LIKE \? COLLATE NOCASE/, 'still a case-insensitive match');
  assert.equal(lastArgs[0], '%minecraft%', 'mid-word matches still work');
  assert.equal(lastArgs[1], 'minecraft%', 'and prefix matches sort first');
});

test('the game search offers the most-owned match first, not the shortest', async () => {
  // Ordering by LENGTH(title) buried the answer: typing "mine" offered the five
  // shortest titles on PSN containing those letters, and Minecraft was not
  // among them. Speed would not have saved that list — it was wrong.
  await dbmod.searchGames(spyEnv(), 'mine', 25);
  const order = lastSql.slice(lastSql.indexOf('ORDER BY'));
  assert.ok(
    order.indexOf('owners DESC') < order.indexOf('LENGTH(title)'),
    'how many of us own it outranks how short the name is',
  );
});

/**
 * The body of handleAutocomplete, bounded by the divider that follows it.
 *
 * This used to be `.slice(0, 4000)`, which is a guess about how long the
 * function is, and adding /flag's version and trophy branches pushed the game
 * branch past it. A test that fails because unrelated code grew is a test that
 * gets deleted.
 */
const autocompleteBody = () => {
  const start = SRC.indexOf('async function handleAutocomplete');
  const end = SRC.indexOf('// ------', start);
  const body = SRC.slice(start, end === -1 ? undefined : end);
  /**
   * COMMENTS STRIPPED, and this bit was learned the hard way twice.
   *
   * A test asserting a dead string is GONE trips over the comment explaining
   * why it went: writing "it used to say Pick a version first" put the phrase
   * straight back into the source the assertion reads. Same shape as the em
   * dash that hid in a CSS comment.
   *
   * Whole-line // only, never to the first // on a line, or every string
   * holding https:// loses its tail and the assertions quietly stop seeing the
   * code they claim to check.
   */
  return body.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
};

test('game autocomplete asks the database nothing until two characters are typed', () => {
  // Discord fires the moment the field is focused. A bare focus and a single
  // letter both have better answers than a search, and a search for "a" is a
  // lottery over every game ever released.
  //
  // The MEMBER branch has no such floor and does not need one: the members
  // table is seventy rows, so a one-letter search there is a scan of nothing.
  assert.match(SRC, /const MIN_QUERY = 2/, 'the floor exists');
  assert.match(
    autocompleteBody(),
    /focused\.length < MIN_QUERY/,
    'and the handler checks it before searching games',
  );
});

test('autocomplete answers only for fields it populates', () => {
  // A future option with autocomplete switched on and no handler should get an
  // empty list, not silently get a list of game titles.
  assert.match(SRC, /GAME_FIELDS = new Set\(\['game', 'title'\]\)/);
  assert.match(SRC, /MEMBER_FIELDS = new Set\(\['add', 'remove'\]\)/);
  assert.match(autocompleteBody(), /GAME_FIELDS\.has\(option\.name\)/);
});

test('the member picker is scoped to /rivals, not to any option called add', () => {
  // "add" and "remove" are ordinary words. Keying on the option name alone
  // would hand a list of PSN IDs to some future /flag add: option.
  const fn = SRC.slice(SRC.indexOf('async function handleAutocomplete'));
  assert.match(
    fn.slice(0, 4000),
    /interaction\.data\.name === 'rivals' && MEMBER_FIELDS\.has/,
    'the command name is part of the test',
  );
});

test('/game shows what the member banks, not the game\'s raw worth', async () => {
  /**
   * The bug Martin and JFL__Leon found by comparing notes: both ran /game on
   * Borderlands 2 and both were told 1,400. Rarity is shared, so the raw figure
   * is identical for anybody holding the same trophies — but the card's heading
   * is the word "you", and at 70.41% and 91.44% they bank 980 and 1,274.
   *
   * /backlog has always multiplied. This asserts the /game card does too, and
   * that the working is shown the same way /rank shows it.
   */
  const src = SRC;

  assert.match(src, /function worthLine\(member, banked, fullValue, remaining\)/,
    'the line is a named function, so it can be reasoned about in one place');
  assert.match(src, /worthLine\(member, banked, fullValue, worth\)/, 'and the card calls it');
  assert.ok(
    !/\*\*Worth to you:\*\* \$\{n\(banked\)\} of \$\{n\(fullValue\)\}/.test(
      src.slice(src.indexOf('const owners = await db.gameOwners')),
    ),
    'the raw pair is no longer printed under that heading',
  );
  assert.match(src, /rarity points \\u00d7 \$\{pct\(c\)\} completion/,
    'and the multiplier is explained, not silently applied');
});

test('per-trophy values are never multiplied', async () => {
  // A trophy's worth is a property of the trophy and identical for everyone.
  // Multiplying a 1-point trophy by anybody's completion floors it to nothing,
  // and the top-three list becomes three zeroes.
  const src = SRC;
  const top = src.slice(src.indexOf('const top = ['), src.indexOf('const owners = await db.gameOwners'));
  assert.ok(top.includes('n(t.points)'), 'the trophy list prints the stored value');
  assert.ok(!top.includes('applyCompletion'), 'and does not scale it');
});

/* ---------------------------------------------------------------------------
 * /flag gained a version and a trophy.
 *
 * The gap mods hit: /flag could only say "this whole title is broken", and it
 * said it about every edition at once. Sea of Thieves on PS4 can die while the
 * PS5 list carries on, and there was no way to say so.
 * ------------------------------------------------------------------------ */

test('/flag takes a version and a trophy, both optional', () => {
  const reg = readFileSync(
    fileURLToPath(new URL('../jobs/register-commands.mjs', import.meta.url)), 'utf8',
  );
  const start = reg.indexOf("name: 'flag'");
  // From `options:`, not from the command name — otherwise the command's own
  // `name: 'flag'` pairs with the game option's `required: true`.
  const flag = reg.slice(reg.indexOf('options: [', start), reg.indexOf("name: 'supporter'"));

  for (const field of ['version', 'trophy']) {
    assert.ok(flag.includes(`name: '${field}'`), `${field} option exists`);
  }
  // Optional, so every /flag a mod runs today keeps working unchanged — all
  // editions remains the default because a shutdown usually does kill them all.
  const opts = [...flag.matchAll(/name: '(\w+)',[\s\S]*?required: (\w+)/g)]
    .map((m) => [m[1], m[2]]);
  assert.deepEqual(
    opts.filter(([, req]) => req === 'true').map(([nm]) => nm),
    ['game'],
    'only the game is required',
  );
  assert.match(flag, /name: 'version'[\s\S]*?autocomplete: true/, 'version autocompletes');
  assert.match(flag, /name: 'trophy'[\s\S]*?autocomplete: true/, 'so does trophy');
});

test('the version and trophy pickers read the options already filled in', () => {
  // Discord sends every option value on an autocomplete interaction, not just
  // the focused one. That is the only reason a dependent dropdown works without
  // storing anything between keystrokes.
  const body = autocompleteBody();
  assert.match(body, /FLAG_FIELDS\.has\(option\?\.name\)/, 'scoped to /flag');
  assert.match(body, /interaction\.data\.options\?\.find\(\(o\) => o\.name === name\)/,
    'reads sibling options');
  assert.match(body, /editionsFor\(env, title\)/, 'versions come from the chosen game');
  assert.match(body, /db\.searchTrophies\(env, npCommId, focused/, 'trophies from the chosen edition');
});

test('the dropdowns resolve a game the same way the command does', async () => {
  /**
   * JFL__Leon, with the game sitting in the box and both dropdowns empty:
   * "bot cant find any trophies or versions for uncharted 2 ps3".
   *
   * The pickers were STRICTER THAN THE COMMAND. `/flag` resolves its game with
   * findGame(), which falls back to a LIKE and finds a title however it was
   * typed; the version and trophy dropdowns matched `title = ?` exactly. So a
   * game the command would flag without complaint answered "No options match
   * your search" twice over, with nothing to say why.
   *
   * It bites on exactly the games a mod has to type by hand. A title only
   * reaches the game dropdown if somebody here owns it, so anything old or
   * obscure is typed, and typed is when the trademark sign and the capitals
   * stop lining up.
   */
  const fn = SRC.slice(SRC.indexOf('async function editionsFor'), SRC.indexOf('async function handleAutocomplete'));
  const code = fn.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');

  assert.match(code, /const exact = await db\.gameVersions\(env, title\)/, 'exact first');
  assert.match(code, /if \(exact\.length\) return exact/, 'and it wins when it finds anything');
  assert.match(code, /db\.findGame\(env, title\)/, 'the command\'s own resolver is the fallback');
  assert.match(
    code,
    /guess\?\.title \? db\.gameVersions\(env, guess\.title\)/,
    'and the fallback re-reads every edition of the title it landed on',
  );
});

test('the fallback resolver can find a title an exact match misses', async () => {
  /**
   * The half of the fix that is not shape. findGame carries a LIKE beside its
   * equality, which is why it survives a title typed without its trademark
   * sign, and it takes the SHORTEST match so "Uncharted 2" cannot quietly
   * resolve to a longer game that merely contains those words.
   */
  await dbmod.findGame(spyEnv(), 'Uncharted 2: Among Thieves');
  assert.match(lastSql, /title = \? COLLATE NOCASE/, 'exact is still tried');
  assert.match(lastSql, /OR title LIKE \? COLLATE NOCASE/, 'and a LIKE catches the rest');
  assert.match(lastSql, /ORDER BY LENGTH\(title\) ASC/, 'shortest match, not any match');
  assert.equal(lastArgs[1], '%Uncharted 2: Among Thieves%');
});

test('a blank version flags the trophy across every edition, by name', () => {
  /**
   * This test used to assert the OPPOSITE: that a multi-edition title refused
   * and told the mod to pick a version. JFL__Leon hit that on WWE All Stars,
   * which has two regional stacks, and pointed out that a title with eight
   * would mean running the command eight times. He was right, and it was
   * inconsistent besides: a blank version has always meant "every edition" for
   * a game flag.
   *
   * BY NAME, NOT BY ID, and that distinction is the whole safety of it. Ids are
   * per np_comm_id. Regional stacks usually share them, but "usually" is not
   * something to write flags on, and a remaster with a reordered list would
   * mark the wrong trophy. The id is resolved to a name in one edition and the
   * name is what travels.
   */
  const fn = SRC.slice(SRC.indexOf('async function flagTrophy'), SRC.indexOf('async function flagGame'));
  assert.match(fn, /db\.setTrophyUnobtainableByName\(env, match\.title, row\.name/,
    'blank scopes to the title, matched on the name');
  assert.match(fn, /const scoped = Boolean\(edition\)/, 'and naming a version still narrows it');
  assert.ok(!/Pick a `version` as well/.test(fn), 'the refusal is gone');

  // An unnamed trophy cannot be matched across stacks, so it must not pretend.
  assert.match(fn, /row\.name\n?\s*\? await db\.setTrophyUnobtainableByName|row\.name$/m,
    'the name is what decides whether it can travel');
});

test('the trophy picker no longer demands a version first', () => {
  // It answered "Pick a version first" for any title with stacks, which is most
  // of them, while the version dropdown could not tell those stacks apart
  // anyway. It was asking for a choice it had not made possible.
  const body = autocompleteBody();
  assert.ok(!body.includes('Pick a version first'), 'the dead end is gone');
  assert.match(body, /const npCommId = chosen \|\| editions\?\.\[0\]\?\.np_comm_id/,
    'it falls back to the most-owned edition');
});

test('the version dropdown can tell two stacks of one game apart', () => {
  // WWE All Stars and WWE All Stars (JP) are the same platform with the same
  // trophy count, so the dropdown offered two identical lines.
  const body = autocompleteBody();
  assert.match(body, /String\(e\.np_comm_id\)\.slice\(-8\)/, 'the id tail disambiguates them');
});

test('/overlay hands back a link instead of asking who they are', () => {
  /**
   * The tool this replaces needs a web page where you type your PSN ID into a
   * box, because it has no idea who you are. The bot does, so the command is
   * the generator: no form, no ID to mistype, and the link comes back already
   * correct.
   */
  const fn = SRC.slice(SRC.indexOf('async function overlay('), SRC.indexOf('async function flagTrophy'));

  assert.match(fn, /db\.memberByDiscordId\(env, userId\)/, 'it knows who asked');
  assert.match(fn, /not on the board yet/, 'and says so when they are not registered');
  assert.match(fn, /'\/overlay\/' \+ who \+ qs/, 'the bar');
  assert.match(fn, /'\/overlay\/' \+ who \+ '\/pop'/, 'and the pop, as separate sources');
  assert.match(fn, /encodeURIComponent\(me\.psn_online_id\)/, 'names are escaped into the path');
  assert.match(fn, /ephemeral: true/, 'nobody else needs to see somebody else source URL');

  // Both options are checked against a literal here as well as in the page,
  // because a wrong link is invisible until the person is live.
  assert.match(fn, /position === 'top'/);
  assert.match(fn, /board === 'hide'/);

  // The test link is the whole reason somebody can place the pop at all.
  assert.match(fn, /\?test=gold/, 'and it tells them how to see it on demand');
});

test('the overlay command registers with defaults, not questions', () => {
  const cmds = readFileSync(
    fileURLToPath(new URL('../jobs/register-commands.mjs', import.meta.url)), 'utf8',
  );
  const block = cmds.slice(cmds.indexOf("name: 'overlay'"), cmds.indexOf("name: 'rivals'"));
  assert.match(block, /choices: \[[\s\S]*?value: 'bottom'/, 'position is a choice list');
  assert.match(block, /value: 'hide'/, 'so is hiding the middle');
  assert.ok(!/required: true/.test(block), 'and neither is required');
});

test('flagging a trophy never touches points', () => {
  /**
   * Martin's rule, and it is settled: "we cant take points away from people for
   * earning something that no longer achievable." The flag is a warning to
   * whoever comes next, not a repricing.
   */
  const rescore = readFileSync(
    fileURLToPath(new URL('../jobs/rescore.mjs', import.meta.url)), 'utf8',
  );

  /**
   * The rescore DOES touch `games.unobtainable` — that is the nightly rollover
   * flipping a game dead once its announced closing date passes, and it moves
   * no points. What must never appear is the TROPHY flag reaching the scoring,
   * because that is the version of this feature Martin ruled out.
   */
  assert.ok(!/FROM trophies[\s\S]{0,400}unobtainable/.test(rescore),
    'the rescore never selects the trophy flag');
  assert.ok(!/unobtainable[\s\S]{0,120}points/.test(rescore),
    'and no flag column sits near a points calculation');

  /**
   * Asserting the WORD "points" is absent was the first attempt and it was
   * wrong — the reply says "Nobody loses points for having earned it", which is
   * the sentence most worth keeping. Assert on the db calls instead: the only
   * two writes this handler makes are the two flags.
   */
  const fn = SRC.slice(SRC.indexOf('async function flagTrophy'), SRC.indexOf('async function flagGame'));
  /**
   * THE SLICE IS THE FRAGILE PART. It runs from one function to the next, so
   * anything dropped between them joins the list and fails this test with a
   * name that has nothing to do with flags. That happened the day /overlay was
   * added: `memberByDiscordId` appeared here and the failure read as if the
   * flag handler had grown a member lookup. The fix is to put new handlers
   * somewhere else, not to widen this list.
   */
  const calls = [...fn.matchAll(/db\.(\w+)\(/g)].map((m) => m[1]).sort();
  assert.deepEqual(
    [...new Set(calls)],
    ['deadCountsByEdition', 'gameVersions', 'setAllTrophies', 'setTrophyUnobtainable',
     'setTrophyUnobtainableByName', 'setUnobtainable', 'trophyRow'],
    'flag writes and lookups only — nothing here can move a score',
  );
  assert.match(fn, /Nobody loses points for having earned it/,
    'and the mod is told so in the reply');
});

test('the game flag is rolled up from its trophies, and cleared with the last one', () => {
  // A mod who marks a trophy broken has said the game cannot be completed.
  // Making them run /flag twice is how a game ends up with a dead trophy and no
  // warning on it — and a hand-set flag would never come off when it was fixed.
  const fn = SRC.slice(SRC.indexOf('async function flagTrophy'), SRC.indexOf('async function flagGame'));
  // Counts come from the table in ONE query across every edition touched, not
  // per edition and not inferred from what was just written: two mods flagging
  // the same title at once would otherwise disagree about the total.
  assert.match(fn, /db\.deadCountsByEdition\(env, affected\.map/, 'counts what is actually flagged');
  assert.match(fn, /on: dead > 0/, 'game flag follows the count, in both directions');
  assert.match(fn, /npCommId: e\.np_comm_id/, 'each edition brought into line on its own row');
});

test('a closing date on a single trophy is refused, not ignored', () => {
  // Same class of bug parseClosingDate exists to prevent: a mod believes they
  // set a countdown, it never appears, nobody finds out until the servers go.
  const fn = SRC.slice(SRC.indexOf('async function flagTrophy'), SRC.indexOf('async function flagGame'));
  assert.match(fn, /if \(closesAt\) \{[\s\S]{0,200}errorReply/, 'it errors');
});

/**
 * flagGame's source, bounded by the NEXT function rather than by a character
 * count. These assertions used to slice a flat 9,000 characters, which is fine
 * until somebody adds a branch: `namechange:` pushed the closing-date logic past
 * the window and three tests went red having found nothing rather than having
 * found something wrong. A window that shrinks as the function grows is a test
 * that stops testing without saying so.
 */
const flagSrc = (() => {
  const at = SRC.indexOf('async function flagGame');
  const end = SRC.indexOf('async function ', at + 10);
  const body = SRC.slice(at, end === -1 ? undefined : end);
  assert.ok(body.length > 2000, 'the slice actually covers the function');
  return body;
})();

test('a typed-in version is checked against the database, not trusted', () => {
  // A mod can type into an autocomplete box instead of picking from it.
  const fn = flagSrc;
  assert.match(fn, /db\.gameById\(env, wanted\)/, 'the id is looked up');
  assert.match(fn, /is not an edition I know/, 'and rejected if it is not real');
  assert.match(fn, /Pick the game again/, 'and if it belongs to another title');
});

test('a closing date with a note counts down — it does not kill the game today', () => {
  /**
   * The bug this replaces: `on: Boolean(clean)` meant the obvious command —
   *
   *   /flag <game> closes:2027-03-15 note:"Servers shut down"
   *
   * — marked the game unobtainable that night, eighteen months early, and the
   * countdown the mod thought they were setting never mattered because the game
   * was already dead. A note is now the REASON for the countdown.
   */
  const fn = flagSrc;
  assert.match(fn, /on: Boolean\(clean\) && !closesAt/,
    'a date means not yet, whatever else was typed');
  assert.ok(!/on: Boolean\(clean\),/.test(fn),
    'and the old unconditional form is gone');
});

test('a note with no date still means broken now', () => {
  // The other half. A moderator writing a note and no date is saying the game
  // is already gone, which is what /flag was built for.
  const fn = flagSrc;
  assert.match(fn, /### ⚠️ \$\{match\.title\} flagged/, 'the dead reply exists');
  assert.ok(!/Also counting down/.test(fn),
    'and it no longer mentions a countdown, because that path cannot be reached');
});

test('the countdown reply carries the reason and says nothing is dead yet', () => {
  const fn = flagSrc;
  const window = fn;
  assert.match(window, /if \(closesAt\) \{/, 'one branch for every dated flag');
  assert.match(window, /clean \? `\\n\\n> \$\{clean\}` : ''/, 'the mod\'s words are shown back');
  assert.match(window, /Nothing is unobtainable yet/, 'and the state is stated plainly');
});

test('a closing date is scoped to one edition when a version is given', () => {
  // Sea of Thieves on PS4 can die while the PS5 list carries on. The date has
  // to follow the same scoping the dead flag does, or a mod scopes the flag and
  // silently sets a countdown on all three editions anyway.
  const fn = flagSrc;
  const call = fn.slice(fn.indexOf('db.setUnobtainable'), fn.indexOf('if (!clean && !closesAt)'));
  assert.match(call, /closesAt,/, 'the date goes through');
  assert.match(call, /npCommId: edition\?\.np_comm_id \?\? null/, 'with the edition beside it');
});

test('clearing a game clears its flagged trophies too, and counts them', () => {
  /**
   * The bug: `/flag <game>` with nothing else printed "Flag cleared -
   * completable again" in green and only ever touched the games row. Every
   * flagged trophy in the game kept its warning on every page while the mod had
   * been told it was fixed.
   *
   * A FALSE SUCCESS IS WORSE THAN AN ERROR. Nobody goes looking for a bug they
   * have been told is already solved — Martin only found this because the
   * warning was still visibly sitting on the trophy.
   */
  const fn = flagSrc;
  const branch = fn.slice(fn.indexOf('if (!clean && !closesAt)'), fn.indexOf('const spread'));
  assert.match(branch, /db\.clearTrophyFlags\(env, \{/, 'the bare clear reaches the trophies');
  assert.match(branch, /npCommId: edition\?\.np_comm_id \?\? null/, 'scoped like everything else');
  assert.match(branch, /flagged troph\$\{lifted === 1 \? 'y' : 'ies'\} cleared with it/,
    'and the reply says how many, rather than claiming a cleanup that did nothing');
});

test('the clear reply warns about the five-minute page cache', () => {
  // Game pages are cached at the edge for 300s. A mod who clears a flag,
  // refreshes, and still sees it will report the clear as broken — which is
  // exactly the report that found the bug above.
  const fn = flagSrc;
  assert.match(fn, /Pages cache for five minutes/);
});

// ------------------------------------------------------- the stale flag ----

test('the register gate no longer tells anybody the board is in testing', () => {
  /**
   * `HUNTER_ROLE_ID` kept the soft-launch role id for months after the soft
   * launch finished, so every member who tried to join was told "the leaderboard
   * is still in testing" and to ask a mod. Martin reported it as a bug, which is
   * exactly what a stale launch flag looks like from the outside.
   *
   * The flag is now empty in wrangler.toml, and the message it would print if
   * anybody turned it back on says which role is missing rather than making a
   * claim about the state of the project that will rot the same way.
   */
  const whole = SRC.slice(
    SRC.indexOf('async function register'),
    SRC.indexOf('function verificationPrompt'),
  );
  assert.ok(whole.length > 200, 'the slice covers the function');

  // Comments are exempt, the same way test/copy.test.mjs exempts them: the
  // block above this gate quotes the old line to explain why it went, and a
  // test that cannot tell an explanation from the thing it explains would force
  // the reasoning out of the file.
  const fn = whole.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  assert.ok(!/still in testing/i.test(fn), 'the testing line is gone');
  assert.ok(!/want in early/i.test(fn), 'and so is the invite-list wording');
  assert.match(fn, /invite only/i, 'it says what is true instead');
  assert.match(fn, /HUNTER_ROLE_ID/, 'and still names the role that is missing');
});

test('the board is open: HUNTER_ROLE_ID ships empty', () => {
  const toml = readFileSync(fileURLToPath(new URL('../wrangler.toml', import.meta.url)), 'utf8');
  assert.match(toml, /^HUNTER_ROLE_ID = ""$/m, 'the gate is off');
  // The other half of the same session. An empty owner id silently widens the
  // rename to anybody with Manage Server.
  assert.match(toml, /^DISCORD_OWNER_ID = "\d{5,}"$/m, 'and the owner is set');
});

// ------------------------------------------------------------- /setgame ----

test('/setgame is wired end to end', () => {
  const names = declared();
  assert.match(SRC, /case 'setgame':\s*return setGame\(/, 'dispatched');
  assert.ok(names.has('setGame'), 'to a function that exists');

  const reg = readFileSync(
    fileURLToPath(new URL('../jobs/register-commands.mjs', import.meta.url)),
    'utf8',
  );
  assert.match(reg, /name: 'setgame'/, 'and Discord knows about it');
  // No permission gate: it only ever changes your own bar, like /twitch.
  const block = reg.slice(reg.indexOf("name: 'setgame'"), reg.indexOf("name: 'overlay'"));
  assert.ok(!/default_member_permissions/.test(block), 'and it is not mod only');
});

test('a pin is checked against the hunter\'s own library, not against games', () => {
  // The overlay reads the pinned game out of member_games. A game they do not
  // own would leave the bar with a name and no numbers, and an autocomplete can
  // be typed into rather than picked from.
  const fn = SRC.slice(SRC.indexOf('async function setGame'), SRC.indexOf('async function twitch'));
  assert.ok(fn.length > 500, 'the slice covers the function');
  assert.match(fn, /myGamesForPin/, 'it asks for their games');
  assert.match(fn, /Pick a game from the dropdown/, 'and refuses anything else');
  assert.match(fn, /027-game-pin/, 'a missing migration is named, not printed as SQLite');
});

test('the setgame picker offers np_comm_ids, not titles', () => {
  /**
   * It shares the option NAME with /flag and /game and means something
   * different by it: a pin is an instruction about ONE trophy list, and
   * "God of War" does not say which of three. Checked before the GAME_FIELDS
   * branch or it would quietly hand back titles from the whole database.
   */
  const fn = SRC.slice(SRC.indexOf('async function handleAutocomplete'));
  assert.match(fn, /const isPin = interaction\.data\.name === 'setgame'/);
  assert.ok(
    fn.indexOf('isPin ||') < fn.indexOf('GAME_FIELDS.has(option.name)'),
    'and it is checked before the title branch',
  );
  assert.match(fn, /value: String\(g\.np_comm_id\)/, 'the value is an id');
});
